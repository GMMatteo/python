from ninja import Ninja

gmoney = Ninja("G", "M", "Doggy Treat", "Kibbles", "Mr Wiggles")
gmoney.feed().walk().bathe()

# print(pets.energy)
# print(pets.health)

# print(Ninja.feed)
# print(Ninja)